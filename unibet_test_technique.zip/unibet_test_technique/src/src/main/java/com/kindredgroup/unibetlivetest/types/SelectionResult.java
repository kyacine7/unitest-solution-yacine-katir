package com.kindredgroup.unibetlivetest.types;

public enum SelectionResult {
    WON,
    LOST
}
