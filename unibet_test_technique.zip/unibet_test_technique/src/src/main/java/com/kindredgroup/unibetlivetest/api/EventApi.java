package com.kindredgroup.unibetlivetest.api;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Log4j2
@RequestMapping(Urls.BASE_PATH)
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class EventApi {


    /** TODO
     *  @GetMapping(Urls.EVENTS)
     */


    /** TODO
     *  @GetMapping(Urls.SELECTIONS)
     */


}
