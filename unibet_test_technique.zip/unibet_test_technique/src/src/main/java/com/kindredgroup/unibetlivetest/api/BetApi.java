package com.kindredgroup.unibetlivetest.api;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(Urls.BETS)
@CrossOrigin(origins = "*")
public class BetApi {

    /** TODO
     *  @PostMapping(Urls.ADD_BET)
     */

}
